package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.maps.MapObject;
import com.badlogic.gdx.maps.objects.RectangleMapObject;
import com.badlogic.gdx.maps.tiled.TiledMap;
import com.badlogic.gdx.maps.tiled.TmxMapLoader;
import com.badlogic.gdx.maps.tiled.renderers.OrthogonalTiledMapRenderer;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.Box2DDebugRenderer;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.World;
import com.badlogic.gdx.utils.ScreenUtils;


public class learningtilemap extends ApplicationAdapter {
    World world;
    float cameraWidth;float cameraHeight;float ppm = 100.0f;
    SpriteBatch batch;BodyDef bodyDef;
    OrthographicCamera camera; Body body;
    TiledMap map ;
    Texture texture; Box2DDebugRenderer dr;
    OrthogonalTiledMapRenderer renderer ;
    public void create(){
        world = new World(new Vector2(0,-9.8f),true);dr = new Box2DDebugRenderer();
        batch = new SpriteBatch();
        map = new TmxMapLoader().load("block.tmx");
        renderer = new OrthogonalTiledMapRenderer(map,1/ppm);
        float tileWidth = 16; // Tile size in pixels
        float tileHeight = 16;
        int mapWidth = 60; // Map size in tiles
        int mapHeight = 100;
        cameraWidth = tileWidth * mapWidth;
        cameraHeight = tileHeight * mapHeight;
        bodyDef = new BodyDef();
        bodyDef.type = BodyDef.BodyType.DynamicBody;
        bodyDef.position.set(new Vector2(750/ppm, 500/ppm));
        body = world.createBody(bodyDef);
        CircleShape shape = new CircleShape();
        shape.setRadius(40/ppm);
        FixtureDef fixtureDef = new FixtureDef();
        fixtureDef.shape = shape;
        body.createFixture(fixtureDef);

        camera = new OrthographicCamera();
        camera.setToOrtho(false, cameraWidth/ppm, cameraHeight/ppm);
        for(MapObject object : map.getLayers().get(1).getObjects().getByType(RectangleMapObject.class)){
            Rectangle rec = ((RectangleMapObject) object).getRectangle();
            BodyDef df = new BodyDef();
            df.type = BodyDef.BodyType.StaticBody;
            df.position.set((rec.getX() + rec.getWidth()/2)/ppm,( rec.getY() + rec.getHeight()/2)/ppm);
            body  = world.createBody(df);
            PolygonShape shapes = new PolygonShape();
            shapes.setAsBox(rec.getWidth()/2/ppm,rec.getHeight()/2/ppm);
            FixtureDef fd = new FixtureDef();
            fd.shape = shapes;body.createFixture( fd);

        }

    }
    public void render(){
        ScreenUtils.clear(0.9f, 0.1f, 0.5f, 1);
        renderer.setView(camera);
        renderer.render();
        batch.setProjectionMatrix(camera.combined);
        world.step(Gdx.graphics.getDeltaTime(),6,2);
        dr.render(world,camera.combined);

        if (Gdx.input.isKeyPressed(Input.Keys.A)) {
            body.applyForceToCenter(new Vector2(2/ppm,0),true);
        } else if (Gdx.input.isKeyPressed(Input.Keys.D)) {
            body.applyForceToCenter(new Vector2(-2/ppm,0),true);
        } else if (Gdx.input.isKeyPressed(Input.Keys.W)) {
            body.applyForceToCenter(new Vector2(0,8/ppm),true);

        }

    }


}
